#' A function to calculate the sum

my_sum<-function(x){
  sum_resutls<-sum(x)
  return(sum_resutls)
}
