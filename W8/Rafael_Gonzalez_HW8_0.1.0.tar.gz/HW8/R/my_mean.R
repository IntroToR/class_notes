
#' A function to calculate the mean

my_mean<-function(x){
  mean_results<-sum(x)/length(x)
  return(mean_results)
}

