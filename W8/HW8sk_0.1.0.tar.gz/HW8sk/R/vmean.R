#mean with na.omit applied
#param vector of values

#returns mean of values

vmean <-
function(v){
  mid<-na.omit(v)
  fin<-sum(mid)/length(mid)
  return(fin)}
