#sum with na.omit applied
#param vector of values

#return single sum

vsum <-
function(b){
  mi<-na.omit(b)
  fi<-sum(mi)
  return(fi)}
