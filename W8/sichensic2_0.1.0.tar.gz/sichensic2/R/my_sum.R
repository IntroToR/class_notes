#' A sum function
#'
#' This package calcutaes the sum
#' @param x a vector to be used to calculate the sum
#' @return the sum
#' @export


my_sum <- function(x) {
  sum(x)
}

