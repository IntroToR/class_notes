#' A average function
#'
#' This package calcutaes the average
#' @param x a vector to be used to calculate the average
#' @return a value
#' @export


my_average <- function(x) {
  sum(x[!is.na(x)])/ length(x[!is.na(x)])
}


