my_mean = function(x) {
  num = 0
  for (i in 1:length(x)) {
    if (!is.na(x[i])) {
      num = num + x[i]
    }
  }

  den = 0
  for (j in 1:length(x)) {
    if (!is.na(x[j])) {
      den = den + 1
    }
  }

  m = num/den

  return(m)
}
