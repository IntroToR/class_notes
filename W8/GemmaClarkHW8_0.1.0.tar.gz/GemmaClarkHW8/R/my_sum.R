my_sum = function(x) {
  a = 0
  for (i in 1:length(x)) {
    if (!is.na(x[i])) {
      a = a + x[i]
    }
  }
  return(a)
}
