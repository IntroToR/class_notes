#' A function which calculates the mean
#'
#' My mean package calculates the mean of a vector
#' @param x a vector to which the mean will be calculated
#'
#' @return a value
#' @export
#'

Mymeanfunction <- function(x) {
  sum(x[!is.na(x)]) / length(x[!is.na(x)])
}
