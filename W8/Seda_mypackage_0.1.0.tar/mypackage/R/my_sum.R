#' A function which calculates the sum
#'
#' My sum package calculates the sum of a vector
#' @param x a vector to which the sum will be calculated
#'
#' @return a value
#' @export
#'

my_sum <- function(x) {
  sum(x)
}
