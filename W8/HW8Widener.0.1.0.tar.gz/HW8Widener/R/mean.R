#my_mean

my_mean <- function(x) {
  y <- sum(x, na.rm = T)/length(x[!is.na(x)])
  return(y)
}
