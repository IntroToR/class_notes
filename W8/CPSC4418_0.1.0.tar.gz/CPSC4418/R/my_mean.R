#' A function that calculates the average of a variable
#'
#' A package to calculate the mean
#' @param x a vector to be used to calculate the mean
#'
#'
#' @return a value
#' @export




my_mean <- function(x){
  sum(x)/length(x)
}

