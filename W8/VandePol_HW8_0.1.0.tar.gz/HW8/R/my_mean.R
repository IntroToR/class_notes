# my_mean
#
# This is a function named 'my_mean'
# which prints the mean of a vector.
#

my_mean <- function(x) {
  y <- sum(x, na.rm = T)/length(x[!is.na(x)])
  return(y)
}

