# my_sum
#
# This is a function named 'my_sum'
# which prints the sum of a vector.
#

my_sum <- function(x) {
  y <- sum(x, na.rm = T)
  return(y)
}
