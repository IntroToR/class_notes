#' A function to calculate the sum of a numeric vector
#'
#'
#' @param x a vector input used to calculate the sum
#' @return a value
#' @author Beau
#' @export

my_sum<-function(x){
  sum(x, na.rm=T)
}
