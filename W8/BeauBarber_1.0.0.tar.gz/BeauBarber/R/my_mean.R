#' A function to calculate the mean of a numeric vector
#'
#'
#' @param x a vector input used to calculate the mean
#' @return a value
#' @author Beau
#' @export

my_mean <- function(x){
  sum(x[!is.na(x)]) / length(x[!is.na(x)])
}
