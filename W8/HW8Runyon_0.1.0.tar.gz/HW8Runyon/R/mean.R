#' A function to calculate the mean
#'
#' This package calculates the mean of a vector
#'
#' @param x a vector to be used to calculate the mean
#'
#' @return a value
#' @export
#'

my_mean<-function(x){
  sum(x[!is.na(x)])/length(x[!is.na(x)])
}
