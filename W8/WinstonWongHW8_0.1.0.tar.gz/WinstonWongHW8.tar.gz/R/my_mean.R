
#'This is a function named "my_mean" which prints the mean of a vector by summing the values in the vector and dividing by the length of the vector
#'
#' My package is calculating the mean of a vector
#' @param x a vector to be used to calculate the mean
#'
#' @return a value
#' @export
#' @examples
#'

my_mean <- function(x) {
  sum(x[!is.na(x)])/length(x[!is.na(x)])
}
