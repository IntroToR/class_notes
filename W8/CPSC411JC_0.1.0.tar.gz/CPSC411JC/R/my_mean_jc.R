#'My package is calculating the mean and a sum of a vector
#'
#'@param x a vector to be used to calculate a mean
#'@return a value
#'@export
#'
my_mean= function(x) {
  sum(x[!is.na(x)])/ length(x[!is.na(x)])
}

my_sum= function(x){
  sum(x[!is.na(x)])
}

