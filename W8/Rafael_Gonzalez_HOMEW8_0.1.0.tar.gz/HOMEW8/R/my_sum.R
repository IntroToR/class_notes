#' A function to calculate the sum
#'
#' My package calculate the sum of a vector
#'
#'@param x is a vector to be used to calculate the sum
#'
#'@return a value
#'
my_sum<-function(x){
  sum_resutls<-sum(x)
  return(sum_resutls)

}
