#' A function to calculate the mean
#'
#' My package calculate the mean of a vector
#'
#'@param x is a vector to be used to calculate the mean
#'
#'@return a value

my_mean<-function(x){
  mean_results<-sum(x)/length(x)
  return(mean_results)

}
