#' A function to calculate the mean
#'
#' This function calculates the mean of a vector of values
#'
#' @param x vector of numbers for which the mean will be calculated
#'
#'
#' @return value of the mean
#' @export
#'
#'
calc_mean<- function(x){
  mean<- (sum(x))/(length(x))
  return(mean)
  }


