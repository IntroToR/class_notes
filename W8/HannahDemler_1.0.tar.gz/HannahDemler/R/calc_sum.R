#' A function to calculate the sum
#'
#' This function calculates the sum of a vector of values.
#'
#' @param x vector of numbers for which the sum will be calculated
#'
#'
#' @return value of the sum
#' @export
#'
#'
calc_sum<- function(x){sum(x)}
