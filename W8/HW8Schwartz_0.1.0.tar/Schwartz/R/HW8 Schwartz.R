#'Takes the sum of a vector and takes its Average
#'
#' This function calculates the mean of a vector
#' @param x a vector to be used to calculate the mean
#' @param y a vector to be used to calculate the sum
#'
#' @return a value
#' @export

Schwartzsum <- function(y) {
  sum(y[!is.na(y)])
}


Schwartzmean <- function(x) {
  sum(x[!is.na(x)])/length(x[!is.na(x)])
}
