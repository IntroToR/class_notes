#' Calculates the Average of a data set
#'
#' This function calculates the mean of a vector
#' @param x a vector to be used to calculate the mean

#'
#' @return a value
#' @export
#'
Schwartzmean <- function(x) {
  sum(x[!is.na(x)])/length(x[!is.na(x)])
}
