#'Mean Calculator
#'
#'This package is to calculate the mean of the vector
#'
#'@return mean value
#'
my_mean<-function(x){
  sum(x[!is.na(x)])/length(x[!is.na(x)])
}
