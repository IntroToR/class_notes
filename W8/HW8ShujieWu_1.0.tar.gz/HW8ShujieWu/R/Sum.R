#'Sum Calculator
#'
#'This package is to calculate the sum of the vector
#'
#'@return sum value

my_sum<-function(x){
  sum(x[!is.na(x)])
}
