#' A function which calculates the mean
#'
#' This package calculates the mean of a vector
#' @param x a vector to which the mean will be calculated
#'
#' @return a value
#' @export
#'
my_mean <- function(x) {
  sum(x[!is.na(x)]) / length(x[!is.na(x)])
}

