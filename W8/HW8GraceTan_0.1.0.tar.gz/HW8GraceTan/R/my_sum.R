#'A function called "my_sum" which prints the sum of a vector by adding the values in the vector
#'
#' My package is calculating the mean of a vector
#' @param x a vector to be used to calculate the sum
#'
#' @return a value
#' @export

my_sum <- function(x) {
  sum(x[!is.na(x)])
}
