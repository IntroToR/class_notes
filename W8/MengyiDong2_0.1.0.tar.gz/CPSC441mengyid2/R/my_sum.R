#' A function to calculated the sum of a vector
#'
#' This package is calculating the sum of a vector
#' @param x a vector to be used to calculate the sum
#'
#' @return a value
#' @export
#'
#'
my_sum <- function(x) {
  sum(x)
}
