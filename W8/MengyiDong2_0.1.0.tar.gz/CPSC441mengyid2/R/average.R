#' A function to calculated the mean
#'
#' This package is calculating the mean of a vector
#' @param x a vector to be used to calculate the mean
#'
#' @return a value
#' @export
#'
#'
average <- function(x) {
  sum(x[!is.na(x)])/ length(x[!is.na(x)])
}
