#' finds the sum of x
#'
#' this package calculates the sum of a vector
#'
#' @param x: a vector used, that the mean will be calculated from
#' @return: mean_answer, the mean of x
#'
mean_of_x <- function(x){
  mean_answer <- sum(x[!is.na(x)])/length(x[!is.na(x)])
  return(mean_answer)
}



