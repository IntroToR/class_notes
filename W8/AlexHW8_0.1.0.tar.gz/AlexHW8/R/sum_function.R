#' finds the sum of x
#'
#' this package calculates the sum of a vector
#'
#' @param x: a vector used, that the sum will be calculated from
#' @return: sum_answer, the sum of x
#'

sum_of_x <- function(x){
  sum_answer <- sum(x[!is.na(x)])
  return(sum_answer)
}

