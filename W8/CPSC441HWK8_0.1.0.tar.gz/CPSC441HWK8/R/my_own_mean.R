#'Making a function that calculates the mean
#'
#'
#'Takes the sum of the data points divided by the number of data points
#'
#'
#'@author
#'
#'Bind two factors
#'
#'Create a nbew factor from two exsting factors, where the new factor's levels
#'are the union of the levels of the inputs
#'
#'@param x a vector to calculate My_own_mean
#'
#'@return a value
#'@export
#'
My_own_mean <- function(x){
  sum(x[!is.na(x)])/length(x[!is.na(x)])
}
