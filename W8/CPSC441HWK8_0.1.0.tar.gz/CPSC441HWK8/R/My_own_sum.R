#'Making a function that calculates the mean
#'
#'
#'Takes the sum of the data points
#'
#'
#'@author
#'
#'Bind two factors
#'
#'Create a new factor from two exsting factors, where the new factor's levels
#'are the union of the levels of the inputs
#'
#'@param x a vector to calculate My_own_sum
#'
#'@return a value
#'@export
#'
My_own_sum <- function(x){
  sum(x[!is.na(x)])
}
