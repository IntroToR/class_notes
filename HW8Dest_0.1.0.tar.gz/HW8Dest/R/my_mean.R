#' This function calculates the mean of a data set
#' 
#' @param x 
#' @return a value
#' @export

means <- function(x) {
  sum(x,na.rm =T)/length(!is.na(x))
  
}