#' This function calculates the sum of all points of a data set
#' 
#' @param x 
#' @return a value
#' @export
#' 

sums <- function(x) {
  y <- length(x)
  z <- 0
  i <- 1
  for (i in y) {
    z <- z + x
    i <- i +1
  }
  sum(z)
}